export const environment = {
    production: true,
    api: {
        search: "/assets/data/db.json"
    }
};
